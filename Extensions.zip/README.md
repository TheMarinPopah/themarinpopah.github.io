# skebstore

A very primitive alternative extension installer for Skiovox users with the Web Store blocked.
Pull requests and improvements are appreciated.

For example, we need to:
- Add an icon
- Add code to style.css